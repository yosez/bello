#pragma once

#ifndef EXP_H
#define EXP_H

#include <stdio.h>
#include <string.h>
#include <math.h>

#include "dftn.h"
#include "cnst.h"
#include "envr.h"
#include "arr.h"
#include "stmt.h"
#include "expt.h"
#include "cls.h"
#include "vrb.h"

extern struct StmtRsltStrc* exctStmt(vector<EnvrStrc*>& envr, struct StmtStrc* stmt);

extern VrbStrc* getObjVrb(VrbStrc* vrb, LvlExpStrc* lvl);
extern CnstStrc* bldCnstFrmVrb(struct VrbStrc* vrb);
extern VrbStrc* getEnvrVrb(struct EnvrStrc* envr, struct VrbExpStrc* vrbExp);
extern NtvFcnStrc* getNtvFcn(struct EnvrStrc* envr, struct FcnExpStrc* fcn);
extern NtvFcnStrc* getNtvFcn(vector<EnvrStrc*> envr, struct FcnExpStrc* fcn);
extern FcnStrc* getFcn(vector<EnvrStrc*> envr, struct FcnExpStrc* fcnExp);
extern VrbStrc* getVrb(vector<EnvrStrc*>& envr, struct VrbExpStrc* vrbExp);
extern VrbStrc* getVrb(vector<EnvrStrc*>& envr, struct LvlExpStrc* lvl);
extern int addFcn(struct EnvrStrc* envr, struct FcnStrc* fcn);
extern struct ClsStrc* getGlbCls(vector<EnvrStrc*>& envr, string nm);

//struct CnstStrc* bldCnstIntExp(int intVl);
//struct CnstStrc* bldCnstFltExp(float fltVl);
//struct CnstStrc* bldCnstBlnExp(int blnVl);
//struct CnstStrc* bldCnstStrExp(char* strVl);
//struct CnstStrc* bldCnstNllExp();
//struct AsgnExpStrc* bldAsgnExp(struct ExpStrc* lvl, struct ExpStrc* exp);
//struct VrbExpStrc* bldVrbExp(char* idtf);
//struct BnrExpStrc* bldBnrExp(int opr, struct ExpStrc* lftExp, struct ExpStrc* rghtExp);
//struct UnrExpStrc* bldUnrExp(int opr, struct ExpStrc* exp);
//struct FcnExpStrc* bldFcnExp(char* nm, struct ArgLstStrc* argLst);
//struct ArrExpStrc* bldArrExp(struct ElmtLstStrc* elmtLst);
//struct LvlExpStrc* bldLvlExp(struct ExpStrc* vrb);
//struct ExpStrc* bldLvlExpAdd(struct ExpStrc* lvl, struct AcsLstStrc* evlLst);
//struct ElmtAsgnExpStrc* bldElmtAsgnExp(struct ExpStrc* arr, struct PstnLstStrc* pstnLst, struct ExpStrc* vl);
//struct NewArrExpStrc* bldNewArrExp(struct ExpStrc* cnt);

struct ExpStrc* bldCnstIntExp(int intVl);
struct ExpStrc* bldCnstFltExp(float fltVl);
struct ExpStrc* bldCnstBlnExp(int blnVl);
struct ExpStrc* bldCnstStrExp(char* strVl);
struct ExpStrc* bldCnstNllExp();
struct ExpStrc* bldAsgnExp(struct ExpStrc* lvl, struct ExpStrc* exp);
struct ExpStrc* bldVrbExp(char* idtf);
struct ExpStrc* bldBnrExp(int opr, struct ExpStrc* lftExp, struct ExpStrc* rghtExp);
struct ExpStrc* blnTrpExp(int opr, ExpStrc* frstExp, ExpStrc* scndExp, ExpStrc* trdExp);
struct ExpStrc* bldUnrExp(int opr, struct ExpStrc* exp);
struct ExpStrc* bldFcnExp(char* nm, struct ArgLstStrc* argLst);
struct ExpStrc* bldArrExp(struct ElmtLstStrc* elmtLst);
struct ExpStrc* bldLvlExp(struct ExpStrc* vrb);
struct ExpStrc* bldLvlExpAdd(struct ExpStrc* lvl, struct AcsLstStrc* evlLst);
struct ExpStrc* bldElmtAsgnExp(struct ExpStrc* arr, struct PstnLstStrc* pstnLst, struct ExpStrc* vl);
struct ExpStrc* bldNewArrExp(struct ExpStrc* cnt);
struct ExpStrc* bldNewExp(char* cls);

struct CnstStrc* clcBnrExp(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp);
struct CnstStrc* clcBnrExpAdd(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp);
struct CnstStrc* clcBnrExpSub(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp);
struct CnstStrc* clcBnrExpMul(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp);
struct CnstStrc* clcBnrExpDiv(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp);
struct CnstStrc* clcBnrExpAnd(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp);
struct CnstStrc* clcBnrExpOr(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp);
struct CnstStrc* clcBnrExpEq(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp);
struct CnstStrc* clcBnrExpNe(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp);
struct CnstStrc* clcBnrExpGt(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp);
struct CnstStrc* clcBnrExpGe(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp);
struct CnstStrc* clcBnrExpLt(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp);
struct CnstStrc* clcBnrExpLe(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp);
struct CnstStrc* clcBnrExpBitAnd(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp);
struct CnstStrc* clcBnrExpBitOr(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp);
struct CnstStrc* clcBnrExpBitXor(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp);

CnstStrc* clcTnrExp(vector<EnvrStrc*>& envr, TnrExpStrc* exp);
struct CnstStrc* clcTnrExpQm(vector<EnvrStrc*>& envr, struct TnrExpStrc* exp);
struct CnstStrc* clcAsgnExp(vector<EnvrStrc*>& envr, struct AsgnExpStrc* exp);
struct CnstStrc* clcUnrExpPfxInc(vector<EnvrStrc*>& envr, struct UnrExpStrc* exp);
struct CnstStrc* clcUnrExpPfxDec(vector<EnvrStrc*>& envr, struct UnrExpStrc* exp);
struct CnstStrc* clcUnrExpSfxInc(vector<EnvrStrc*>& envr, struct UnrExpStrc* exp);
struct CnstStrc* clcUnrExpSfxDec(vector<EnvrStrc*>& envr, struct UnrExpStrc* exp);
struct CnstStrc* clcUnrExpNot(vector<EnvrStrc*>& envr, struct UnrExpStrc* exp);
struct CnstStrc* clcUnrExpBitNot(vector<EnvrStrc*>& envr, struct UnrExpStrc* exp);
struct CnstStrc* clcUnrExpSub(vector<EnvrStrc*>& envr, struct UnrExpStrc* exp);
struct CnstStrc* clcUnrExpAdd(vector<EnvrStrc*>& envr, struct UnrExpStrc* exp);
struct CnstStrc* clcUnrExp(vector<EnvrStrc*>& envr, struct UnrExpStrc* exp);
struct CnstStrc* clcFcnExp(vector<EnvrStrc*>& envr, struct FcnExpStrc* exp);
struct CnstStrc* clcFcnExp(vector<EnvrStrc*>& envr, struct FcnStrc* fcn, struct FcnExpStrc* exp);
struct CnstStrc* clcArrExp(vector<EnvrStrc*>& envr, struct ArrExpStrc* exp);
struct CnstStrc* clcNewArrExp(vector<EnvrStrc*>& envr, struct NewArrExpStrc* exp);
struct CnstStrc* clcArrEvlExp(vector<EnvrStrc*>& envr, struct ArrEvlExpStrc* exp);
struct CnstStrc* clcElmtAsgnExp(vector<EnvrStrc*>& envr, struct ElmtAsgnExpStrc* exp);
struct CnstStrc* clcLvlExp(vector<EnvrStrc*>& envr, struct LvlExpStrc* exp);
struct CnstStrc* clcNewExp(vector<EnvrStrc*>& envr, struct NewExpStrc* exp);
struct CnstStrc* clcExp(vector<EnvrStrc*>& envr, struct ExpStrc* exp);


struct ExpStrc* bldCnstIntExp(int intVl)
{
	struct CnstStrc* exp;

	exp = bldIntCnst(intVl);

	return exp;
}

struct ExpStrc* bldCnstFltExp(float fltVl)
{
	struct CnstStrc* exp;

	exp = bldFltCnst(fltVl);

	return exp;
}

struct ExpStrc* bldCnstBlnExp(int blnVl)
{
	struct CnstStrc* exp;

	exp = bldBlnCnst(blnVl);

	return exp;
}

struct ExpStrc* bldCnstStrExp(char* strVl)
{
	struct CnstStrc* exp;

	exp = bldStrCnst(strVl);

	return exp;
}

struct ExpStrc* bldCnstNllExp()
{
	struct CnstStrc* exp;

	exp = bldNllCnst();

	return exp;
}

struct ExpStrc* bldAsgnExp(struct ExpStrc* lvl, struct ExpStrc* exp)
{
	struct AsgnExpStrc* rslt = new AsgnExpStrc;

	rslt->typ = ASSIGN_EXPRESSION;

	rslt->lvl = static_cast<LvlExpStrc*>(lvl);
	rslt->exp = exp;

	return rslt;

}


struct ExpStrc* bldArrExp(struct ElmtLstStrc* elmtLst)
{
	struct ArrExpStrc* rslt = new ArrExpStrc;

	rslt->typ = ARRAY_EXPRESSION;

	rslt->elmtLst = elmtLst;

	return rslt;
}

struct ExpStrc* bldLvlExp(struct ExpStrc* vrb)
{
	struct LvlExpStrc* rslt = new LvlExpStrc;

	rslt->typ = LVALUE_EXPRESSION;

	rslt->vrb = static_cast<VrbExpStrc*>(vrb);

	rslt->hasAcsLst = 0;
	rslt->acs = nullptr;

	rslt->hasAtb = 0;
	rslt->atb = nullptr;

	rslt->hasFcn = 0;
	rslt->fcn = nullptr;

	rslt->blnIvk = 0;

	return rslt;
}

struct ExpStrc* bldLvlExpAdd(struct ExpStrc* lvl, struct AcsLstStrc* evlLst)
{

	static_cast<LvlExpStrc*>(lvl)->acs = evlLst;

	if (evlLst != NULL)
	{
		static_cast<LvlExpStrc*>(lvl)->hasAcsLst = 1;
	}

	return lvl;
}

struct ExpStrc* bldElmtAsgnExp(struct ExpStrc* arr, struct PstnLstStrc* pstnLst, struct ExpStrc* vl)
{
	struct ElmtAsgnExpStrc* rslt = new ElmtAsgnExpStrc;

	rslt->typ = ELEMENT_ASSIGN_EXPRESSION;

	rslt->arr = arr;
	rslt->pstnLst = pstnLst;
	rslt->vl = vl;

	return rslt;
}


struct ExpStrc* bldNewArrExp(struct ExpStrc* cnt)
{
	struct NewArrExpStrc* rslt = new NewArrExpStrc;

	rslt->typ = NEW_ARRAY_EXPRESSION;

	rslt->cnt = cnt;

	return rslt;
}

struct ExpStrc* bldNewExp(char* cls)
{
	auto rslt = new NewExpStrc;
	rslt->typ = NEW_EXPRESSION;
	rslt->nm = new string(cls);

	return rslt;
}


struct ExpStrc* bldVrbExp(char* nm)
{
	struct VrbExpStrc* exp = new VrbExpStrc;

	exp->typ = VARIABLE_EXPRESSION;

	exp->nm = nm;

	return exp;
}

struct ExpStrc* bldBnrExp(int opr, struct ExpStrc* lftExp, struct ExpStrc* rghtExp)
{
	struct BnrExpStrc* exp = new BnrExpStrc;

	exp->typ = BINARY_EXPRESSION;

	exp->lftExp = lftExp;
	exp->rghtExp = rghtExp;
	exp->oprTyp = opr;

	return exp;
}

struct ExpStrc* bldTnrExp(int opr, ExpStrc* frstExp, ExpStrc* scndExp, ExpStrc* trdExp)
{
	TnrExpStrc* exp = new TnrExpStrc;

	exp->typ = TERNARY_EXPRESSION;

	exp->oprTyp = opr;

	exp->frstExp = frstExp;
	exp->scndExp = scndExp;
	exp->trdExp = trdExp;

	return exp;
}

struct ExpStrc* bldUnrExp(int opr, struct ExpStrc* exp)
{
	struct UnrExpStrc* rslt = new UnrExpStrc;

	rslt->typ = UNARY_EXPRESSION;

	rslt->exp = static_cast<LvlExpStrc*>(exp);
	rslt->oprTyp = opr;

	return rslt;
}



struct ExpStrc* bldFcnExp(char* nm, struct ArgLstStrc* argLst)
{
	struct FcnExpStrc* rslt = new FcnExpStrc;

	rslt->typ = FUNCTION_EXPRESSION;

	rslt->nm = nm;

	rslt->argLst = argLst;

	//if (rslt->argLst != nullptr)
	//{
	//	printf("argLst: arg typ: %d\n", rslt->argLst->argArr.at(0)->typ);
	//}

	return rslt;

}

struct ExpStrc* bldNllExp()
{
	struct ExpStrc* rslt = new ExpStrc;

	rslt->typ = NULL_EXPRESSION;

	return rslt;
}

struct CnstStrc* clcBnrExpAdd(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp)
{
	struct CnstStrc* lftCnst = clcExp(envr, exp->lftExp);
	struct CnstStrc* rghtCnst = clcExp(envr, exp->rghtExp);

	printf("bnr exp lft: typ: %d\n", lftCnst->CnstTyp);
	printf("bnr exp rgt: typ: %d\n", rghtCnst->CnstTyp);

	struct CnstStrc* rslt = nullptr;

	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldIntCnst(lftCnst->vl.intVl + rghtCnst->vl.intVl);
	}
	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldFltCnst(lftCnst->vl.intVl + rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldFltCnst(lftCnst->vl.flt + rghtCnst->vl.intVl);
	}

	string str;

	if (lftCnst->CnstTyp == STRING_VALUE && rghtCnst->CnstTyp == STRING_VALUE)
	{
		str = *(lftCnst->vl.str) + *(rghtCnst->vl.str);

		rslt = bldStrCnstByStr(str);
	}

	if (lftCnst->CnstTyp == STRING_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{

		str = *(lftCnst->vl.str);

		str += to_string(rghtCnst->vl.intVl);

		rslt = bldStrCnstByStr(str);
	}

	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == STRING_VALUE)
	{

		str = to_string(lftCnst->vl.intVl);
		str += *(rghtCnst->vl.str);

		rslt = bldStrCnstByStr(str);
	}

	if (lftCnst->CnstTyp == STRING_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{

		str = *lftCnst->vl.str;
		str += to_string(rghtCnst->vl.flt);

		rslt = bldStrCnstByStr(str);
	}

	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == STRING_VALUE)
	{

		str = to_string(lftCnst->vl.flt);
		str += *(rghtCnst->vl.str);

		rslt = bldStrCnstByStr(str);
	}

	if (lftCnst->CnstTyp == STRING_VALUE && rghtCnst->CnstTyp == BOOLEAN_VALUE)
	{

		str = *(lftCnst->vl.str);

		str += rghtCnst->vl.bln == 0 ? "false" : "true";

		rslt = bldStrCnstByStr(str);
	}

	if (lftCnst->CnstTyp == BOOLEAN_VALUE && rghtCnst->CnstTyp == STRING_VALUE)
	{

		str = lftCnst->vl.bln == 0 ? "false" : "true";

		str += *(rghtCnst->vl.str);

		rslt = bldStrCnstByStr(str);
	}

	if (rslt == nullptr)
	{
		printf("bnr exp err\n");
		throw new ExWrgOprndTyp;
	}

	return rslt;

}

struct CnstStrc* clcBnrExpSub(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp)
{
	struct CnstStrc* lftCnst = clcExp(envr, exp->lftExp);
	struct CnstStrc* rghtCnst = clcExp(envr, exp->rghtExp);

	struct CnstStrc* rslt = NULL;

	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldIntCnst(lftCnst->vl.intVl - rghtCnst->vl.intVl);
	}
	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldFltCnst(lftCnst->vl.intVl - rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldFltCnst(lftCnst->vl.flt - rghtCnst->vl.intVl);
	}

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;

}

struct CnstStrc* clcBnrExpMul(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp)
{
	struct CnstStrc* lftCnst = clcExp(envr, exp->lftExp);
	struct CnstStrc* rghtCnst = clcExp(envr, exp->rghtExp);

	struct CnstStrc* rslt = NULL;

	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldIntCnst(lftCnst->vl.intVl * rghtCnst->vl.intVl);
	}
	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldFltCnst(lftCnst->vl.intVl * rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldFltCnst(lftCnst->vl.flt * rghtCnst->vl.intVl);
	}

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;

}

struct CnstStrc* clcBnrExpDiv(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp)
{
	struct CnstStrc* lftCnst = clcExp(envr, exp->lftExp);
	struct CnstStrc* rghtCnst = clcExp(envr, exp->rghtExp);

	struct CnstStrc* rslt = NULL;

	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldIntCnst(lftCnst->vl.intVl / rghtCnst->vl.intVl);
	}
	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldFltCnst(lftCnst->vl.intVl / rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldFltCnst(lftCnst->vl.flt / rghtCnst->vl.intVl);
	}

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;

}

struct CnstStrc* clcBnrExpMod(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp)
{
	struct CnstStrc* lftCnst = clcExp(envr, exp->lftExp);
	struct CnstStrc* rghtCnst = clcExp(envr, exp->rghtExp);

	struct CnstStrc* rslt = NULL;

	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldIntCnst(lftCnst->vl.intVl % rghtCnst->vl.intVl);
	}
	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldFltCnst(fmod(lftCnst->vl.intVl, rghtCnst->vl.flt));
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldFltCnst(fmod(lftCnst->vl.flt, rghtCnst->vl.intVl));
	}

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;

}

struct CnstStrc* clcBnrExpEq(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp)
{
	struct CnstStrc* lftCnst = clcExp(envr, exp->lftExp);
	struct CnstStrc* rghtCnst = clcExp(envr, exp->rghtExp);

	struct CnstStrc* rslt = NULL;

	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.intVl == rghtCnst->vl.intVl);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.flt == rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldBlnCnst((float)lftCnst->vl.intVl == rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.flt == (float)rghtCnst->vl.intVl);
	}

	if (lftCnst->CnstTyp == STRING_VALUE && rghtCnst->CnstTyp == STRING_VALUE)
	{
		//rslt = bldBlnCnst(strcmp(lftCnst->vl.str, rghtCnst->vl.str) == 0);
		rslt = bldBlnCnst(lftCnst->vl.str->compare(*rghtCnst->vl.str) == 0);
	}

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;

}

struct CnstStrc* clcBnrExpNe(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp)
{
	struct CnstStrc* lftCnst = clcExp(envr, exp->lftExp);
	struct CnstStrc* rghtCnst = clcExp(envr, exp->rghtExp);

	struct CnstStrc* rslt = NULL;

	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.intVl != rghtCnst->vl.intVl);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.flt != rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldBlnCnst((float)lftCnst->vl.intVl != rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.flt != (float)rghtCnst->vl.intVl);
	}

	if (lftCnst->CnstTyp == STRING_VALUE && rghtCnst->CnstTyp == STRING_VALUE)
	{
		//rslt = bldBlnCnst(strcmp(lftCnst->vl.str, rghtCnst->vl.str) != 0);
		rslt = bldBlnCnst(lftCnst->vl.str->compare(*rghtCnst->vl.str) != 0);
	}

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;

}

struct CnstStrc* clcBnrExpGt(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp)
{
	struct CnstStrc* lftCnst = clcExp(envr, exp->lftExp);
	struct CnstStrc* rghtCnst = clcExp(envr, exp->rghtExp);

	struct CnstStrc* rslt = NULL;

	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.intVl > rghtCnst->vl.intVl);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.flt > rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldBlnCnst((float)lftCnst->vl.intVl > rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.flt > (float)rghtCnst->vl.intVl);
	}

	if (lftCnst->CnstTyp == STRING_VALUE && rghtCnst->CnstTyp == STRING_VALUE)
	{
		rslt = bldBlnCnst(strcmp(lftCnst->vl.str->c_str(), rghtCnst->vl.str->c_str()) > 0);
	}

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;

}

struct CnstStrc* clcBnrExpGe(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp)
{
	struct CnstStrc* lftCnst = clcExp(envr, exp->lftExp);
	struct CnstStrc* rghtCnst = clcExp(envr, exp->rghtExp);

	struct CnstStrc* rslt = NULL;

	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.intVl >= rghtCnst->vl.intVl);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.flt >= rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldBlnCnst((float)lftCnst->vl.intVl >= rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.flt >= (float)rghtCnst->vl.intVl);
	}
	if (lftCnst->CnstTyp == STRING_VALUE && rghtCnst->CnstTyp == STRING_VALUE)
	{
		//rslt = bldBlnCnst(strcmp(lftCnst->vl.str, rghtCnst->vl.str) >= 0);
		rslt = bldBlnCnst(lftCnst->vl.str->compare(*rghtCnst->vl.str) >= 0);
	}

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;

}



struct CnstStrc* clcBnrExpLt(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp)
{
	struct CnstStrc* lftCnst = clcExp(envr, exp->lftExp);
	struct CnstStrc* rghtCnst = clcExp(envr, exp->rghtExp);

	struct CnstStrc* rslt = NULL;

	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.intVl < rghtCnst->vl.intVl);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.flt < rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldBlnCnst((float)lftCnst->vl.intVl < rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.flt < (float)rghtCnst->vl.intVl);
	}
	if (lftCnst->CnstTyp == STRING_VALUE && rghtCnst->CnstTyp == STRING_VALUE)
	{
		//rslt = bldBlnCnst(strcmp(lftCnst->vl.str.c_str(), rghtCnst->vl.str.c_str()) < 0);
		rslt = bldBlnCnst(lftCnst->vl.str->compare(*rghtCnst->vl.str) < 0);
	}

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;

}

struct CnstStrc* clcBnrExpLe(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp)
{
	struct CnstStrc* lftCnst = clcExp(envr, exp->lftExp);
	struct CnstStrc* rghtCnst = clcExp(envr, exp->rghtExp);

	struct CnstStrc* rslt = NULL;

	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.intVl <= rghtCnst->vl.intVl);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.flt <= rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldBlnCnst((float)lftCnst->vl.intVl <= rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.flt <= (float)rghtCnst->vl.intVl);
	}
	if (lftCnst->CnstTyp == STRING_VALUE && rghtCnst->CnstTyp == STRING_VALUE)
	{
		//rslt = bldBlnCnst(strcmp(lftCnst->vl.str.c_str(), rghtCnst->vl.str.c_str()) <= 0);
		rslt = bldBlnCnst(lftCnst->vl.str->compare(*rghtCnst->vl.str) <= 0);
	}

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;

}

struct CnstStrc* clcBnrExpBitAnd(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp)
{
	struct CnstStrc* lftCnst = clcExp(envr, exp->lftExp);
	struct CnstStrc* rghtCnst = clcExp(envr, exp->rghtExp);

	struct CnstStrc* rslt = NULL;

	if ((lftCnst->CnstTyp == INT_VALUE || lftCnst->CnstTyp == FLOAT_VALUE || lftCnst->CnstTyp == BOOLEAN_VALUE) &&
		(rghtCnst->CnstTyp == INT_VALUE || rghtCnst->CnstTyp == FLOAT_VALUE || rghtCnst->CnstTyp == BOOLEAN_VALUE))
	{
		rslt = bldIntCnst(lftCnst->vl.intVl & rghtCnst->vl.intVl);
	}

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;
}

struct CnstStrc* clcBnrExpBitOr(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp)
{
	struct CnstStrc* lftCnst = clcExp(envr, exp->lftExp);
	struct CnstStrc* rghtCnst = clcExp(envr, exp->rghtExp);

	struct CnstStrc* rslt = NULL;

	if ((lftCnst->CnstTyp == INT_VALUE || lftCnst->CnstTyp == FLOAT_VALUE || lftCnst->CnstTyp == BOOLEAN_VALUE) &&
		(rghtCnst->CnstTyp == INT_VALUE || rghtCnst->CnstTyp == FLOAT_VALUE || rghtCnst->CnstTyp == BOOLEAN_VALUE))
	{
		rslt = bldIntCnst(lftCnst->vl.intVl | rghtCnst->vl.intVl);
	}

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;
}

struct CnstStrc* clcBnrExpBitXor(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp)
{
	struct CnstStrc* lftCnst = clcExp(envr, exp->lftExp);
	struct CnstStrc* rghtCnst = clcExp(envr, exp->rghtExp);

	struct CnstStrc* rslt = NULL;

	if ((lftCnst->CnstTyp == INT_VALUE || lftCnst->CnstTyp == FLOAT_VALUE || lftCnst->CnstTyp == BOOLEAN_VALUE) &&
		(rghtCnst->CnstTyp == INT_VALUE || rghtCnst->CnstTyp == FLOAT_VALUE || rghtCnst->CnstTyp == BOOLEAN_VALUE))
	{
		rslt = bldIntCnst(lftCnst->vl.intVl ^ rghtCnst->vl.intVl);
	}

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;
}


struct CnstStrc* clcBnrExpAnd(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp)
{
	struct CnstStrc* lftCnst = clcExp(envr, exp->lftExp);
	struct CnstStrc* rghtCnst = clcExp(envr, exp->rghtExp);

	struct CnstStrc* rslt = NULL;

	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.intVl && rghtCnst->vl.intVl);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.flt && rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.intVl && rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.flt && (float)rghtCnst->vl.intVl);
	}

	if (lftCnst->CnstTyp == BOOLEAN_VALUE || rghtCnst->CnstTyp == BOOLEAN_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.bln && rghtCnst->vl.bln);
	}

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;

}

struct CnstStrc* clcBnrExpOr(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp)
{
	struct CnstStrc* lftCnst = clcExp(envr, exp->lftExp);
	struct CnstStrc* rghtCnst = clcExp(envr, exp->rghtExp);

	struct CnstStrc* rslt = NULL;

	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.intVl || rghtCnst->vl.intVl);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.flt || rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == INT_VALUE && rghtCnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.intVl || rghtCnst->vl.flt);
	}
	if (lftCnst->CnstTyp == FLOAT_VALUE && rghtCnst->CnstTyp == INT_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.flt || (float)rghtCnst->vl.intVl);
	}

	if (lftCnst->CnstTyp == BOOLEAN_VALUE || rghtCnst->CnstTyp == BOOLEAN_VALUE)
	{
		rslt = bldBlnCnst(lftCnst->vl.bln || rghtCnst->vl.bln);
	}

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;

}



struct CnstStrc* clcBnrExp(vector<EnvrStrc*>& envr, struct BnrExpStrc* exp)
{
	struct CnstStrc* rslt;

	switch (exp->oprTyp)
	{
		//处理相同类型及不同类型变量之间的运算
	case ADD:
	{
		rslt = clcBnrExpAdd(envr, exp);

		break;
	}
	case SUB:
	{
		rslt = clcBnrExpSub(envr, exp);

		break;
	}
	case MUL:
	{
		rslt = clcBnrExpMul(envr, exp);
		break;
	}
	case DIV:
	{
		rslt = clcBnrExpDiv(envr, exp);
		break;
	}
	case MOD:
	{
		rslt = clcBnrExpMod(envr, exp);
		break;
	}
	case EQ:
	{
		rslt = clcBnrExpEq(envr, exp);
		break;
	}
	case NE:
	{
		rslt = clcBnrExpNe(envr, exp);
		break;
	}
	case GT:
	{
		rslt = clcBnrExpGt(envr, exp);
		break;
	}
	case GE:
	{
		rslt = clcBnrExpGe(envr, exp);
		break;
	}
	case LT:
	{
		rslt = clcBnrExpLt(envr, exp);
		break;
	}
	case LE:
	{
		rslt = clcBnrExpLe(envr, exp);
		break;
	}
	case AND:
	{
		rslt = clcBnrExpAnd(envr, exp);
		break;
	}
	case OR:
	{
		rslt = clcBnrExpOr(envr, exp);
		break;
	}
	case BIT_AND:
	{
		rslt = clcBnrExpBitAnd(envr, exp);
		break;
	}
	case BIT_OR:
	{
		rslt = clcBnrExpBitOr(envr, exp);
		break;
	}
	case BIT_XOR:
	{
		rslt = clcBnrExpBitXor(envr, exp);
	}

	}

	return rslt;
}

CnstStrc* clcTnrExp(vector<EnvrStrc*>& envr, TnrExpStrc* exp)
{
	CnstStrc* rslt = nullptr;
	switch (exp->oprTyp)
	{
	case QM:
	{
		rslt = clcTnrExpQm(envr, exp);
		break;
	}
	}

	return rslt;
}

CnstStrc* clcTnrExpQm(vector<EnvrStrc*>& envr, TnrExpStrc* exp)
{
	CnstStrc* rslt;

	if (clcExp(envr, exp->frstExp)->vl.intVl != 0)
	{
		rslt = clcExp(envr, exp->scndExp);
	}
	else
	{

		rslt = clcExp(envr, exp->trdExp);
	}

	return rslt;
}

struct CnstStrc* clcUnrExpPfxInc(vector<EnvrStrc*>& envr, struct UnrExpStrc* exp)
{
	struct CnstStrc* rslt = new CnstStrc;

	struct LvlExpStrc* lvl;

	//***此修改可能有问题
	lvl = static_cast<LvlExpStrc*>(exp->exp);

	struct VrbStrc* vrb;

	vrb = getVrb(envr, static_cast<VrbExpStrc*>(lvl->vrb));

	if (vrb == NULL)
	{
		throw new ExVrbNotFnd;
	}

	if (lvl->hasAcsLst == 0)
	{
		if (vrb->typ == INT_VALUE)
		{
			vrb->vl.intVl++;
			rslt = bldCnstFrmVrb(vrb);

		}

		if (vrb->typ == FLOAT_VALUE)
		{
			vrb->vl.flt++;
			rslt = bldCnstFrmVrb(vrb);

		}
	}
	//定位到数组元素的情况
	else
	{

		int pstn;

		struct ArrStrc* arrPrnt;

		arrPrnt = vrb->vl.arr;

		int lyr;

		int nbr;

		lyr = lvl->acs->acsLst.size();

		int i;

		for (i = 0; i < lyr; i++)
		{
			pstn = clcExp(envr, lvl->acs->acsLst[i]->pstn)->vl.intVl;

			if (i < lyr - 1)
			{
				arrPrnt = arrPrnt->elmtArr[pstn]->vl.arr;
			}
		}


		if (arrPrnt->elmtArr[pstn]->CnstTyp == INT_VALUE)
		{
			arrPrnt->elmtArr[pstn]->vl.intVl++;
			rslt = bldCnstCpy(arrPrnt->elmtArr[pstn]);

		}

		if (arrPrnt->elmtArr[pstn]->CnstTyp == FLOAT_VALUE)
		{
			arrPrnt->elmtArr[pstn]->vl.flt++;
			rslt = bldCnstCpy(arrPrnt->elmtArr[pstn]);
		}
	}


	return rslt;
}

struct CnstStrc* clcUnrExpPfxDec(vector<EnvrStrc*>& envr, struct UnrExpStrc* exp)
{
	struct VrbStrc* vrb;

	struct CnstStrc* rslt = new CnstStrc;

	struct LvlExpStrc* lvl;

	//***此修改可能有问题
	lvl = static_cast<LvlExpStrc*>(exp->exp);

	//lvl = exp->exp->exp.lvlExp;

	vrb = getVrb(envr, static_cast<VrbExpStrc*>(lvl->vrb));

	if (vrb == NULL)
	{
		throw new ExVrbNotFnd;
	}

	if (lvl->hasAcsLst == 0)
	{
		if (vrb->typ == INT_VALUE)
		{
			vrb->vl.intVl--;
			rslt = bldCnstFrmVrb(vrb);

		}

		if (vrb->typ == FLOAT_VALUE)
		{
			vrb->vl.flt--;
			rslt = bldCnstFrmVrb(vrb);

		}
	}
	//定位到数组元素的情况
	else
	{

		int pstn;

		struct ArrStrc* arrPrnt;

		arrPrnt = vrb->vl.arr;

		int lyr;

		lyr = lvl->acs->acsLst.size();

		int i;

		//按层级定位数组中元素的位置，直至arrPrnt定位到包含元素的最内层的数组
		for (i = 0; i < lyr; i++)
		{
			pstn = clcExp(envr, lvl->acs->acsLst[i]->pstn)->vl.intVl;

			if (i < lyr - 1)
			{
				arrPrnt = arrPrnt->elmtArr[pstn]->vl.arr;
			}
		}

		if (arrPrnt->elmtArr[pstn]->CnstTyp == INT_VALUE)
		{
			arrPrnt->elmtArr[pstn]->vl.intVl--;
			rslt = bldCnstCpy(arrPrnt->elmtArr[pstn]);

		}

		if (arrPrnt->elmtArr[pstn]->CnstTyp == FLOAT_VALUE)
		{
			arrPrnt->elmtArr[pstn]->vl.flt--;
			rslt = bldCnstCpy(arrPrnt->elmtArr[pstn]);
		}
	}


	return rslt;
}

struct CnstStrc* clcUnrExpSfxInc(vector<EnvrStrc*>& envr, struct UnrExpStrc* exp)
{
	struct VrbStrc* vrb;

	struct CnstStrc* rslt = new CnstStrc;

	struct LvlExpStrc* lvl;

	//***此修改可能有问题
	//lvl = static_cast<LvlExpStrc*>(exp->exp);
	lvl = exp->exp;

	vrb = getVrb(envr, static_cast<VrbExpStrc*>(lvl->vrb));

	//lvl = exp->exp->exp.lvlExp;

	//vrb = getVrb(envr, lvl->vrb->exp.vrbExp);

	if (vrb == NULL)
	{
		throw new ExVrbNotFnd;
	}

	if (lvl->hasAcsLst == 0)
	{
		if (vrb->typ == INT_VALUE)
		{
			rslt = bldCnstFrmVrb(vrb);

			vrb->vl.intVl++;

		}

		if (vrb->typ == FLOAT_VALUE)
		{
			rslt = bldCnstFrmVrb(vrb);

			vrb->vl.flt++;


		}
	}
	//定位到数组元素的情况
	else
	{

		int pstn;

		struct ArrStrc* arrPrnt;

		arrPrnt = vrb->vl.arr;

		int lyr;

		lyr = lvl->acs->acsLst.size();

		int i;

		for (i = 0; i < lyr; i++)
		{
			pstn = clcExp(envr, lvl->acs->acsLst[i]->pstn)->vl.intVl;
			if (i < lyr - 1)
			{
				arrPrnt = arrPrnt->elmtArr[pstn]->vl.arr;
			}

		}

		if (arrPrnt->elmtArr[pstn]->CnstTyp == INT_VALUE)
		{
			rslt = bldCnstCpy(arrPrnt->elmtArr[pstn]);
			arrPrnt->elmtArr[pstn]->vl.intVl++;


		}

		if (arrPrnt->elmtArr[pstn]->CnstTyp == FLOAT_VALUE)
		{
			rslt = bldCnstCpy(arrPrnt->elmtArr[pstn]);
			arrPrnt->elmtArr[pstn]->vl.flt++;

		}
	}


	return rslt;
}

struct CnstStrc* clcUnrExpSfxDec(vector<EnvrStrc*>& envr, struct UnrExpStrc* exp)
{
	struct VrbStrc* vrb;

	struct CnstStrc* rslt = new CnstStrc;

	struct LvlExpStrc* lvl;

	//***此修改可能有问题
	lvl = exp->exp;

	vrb = getVrb(envr, static_cast<VrbExpStrc*>(lvl->vrb));

	//lvl = exp->exp->exp.lvlExp;

	//vrb = getVrb(envr, lvl->vrb->exp.vrbExp);

	if (vrb == NULL)
	{
		throw new ExVrbNotFnd;
	}

	if (lvl->hasAcsLst == 0)
	{
		if (vrb->typ == INT_VALUE)
		{
			rslt = bldCnstFrmVrb(vrb);

			vrb->vl.intVl--;

		}

		if (vrb->typ == FLOAT_VALUE)
		{
			rslt = bldCnstFrmVrb(vrb);

			vrb->vl.flt--;


		}
	}
	//定位到数组元素的情况
	else
	{

		int pstn;

		struct ArrStrc* arrPrnt;

		arrPrnt = vrb->vl.arr;

		int lyr;

		lyr = lvl->acs->acsLst.size();

		int i;

		for (i = 0; i < lyr; i++)
		{
			pstn = clcExp(envr, lvl->acs->acsLst[i]->pstn)->vl.intVl;
			if (i < lyr - 1)
			{
				arrPrnt = arrPrnt->elmtArr[pstn]->vl.arr;
			}
		}

		if (arrPrnt->elmtArr[pstn]->CnstTyp == INT_VALUE)
		{
			rslt = bldCnstCpy(arrPrnt->elmtArr[pstn]);
			arrPrnt->elmtArr[pstn]->vl.intVl--;


		}

		if (arrPrnt->elmtArr[pstn]->CnstTyp == FLOAT_VALUE)
		{
			rslt = bldCnstCpy(arrPrnt->elmtArr[pstn]);
			arrPrnt->elmtArr[pstn]->vl.flt--;

		}
	}


	return rslt;
}

struct CnstStrc* clcUnrExpNot(vector<EnvrStrc*>& envr, struct UnrExpStrc* exp)
{

	struct CnstStrc* rslt = NULL;

	struct CnstStrc* cnst;
	cnst = clcExp(envr, exp->exp);

	if (cnst->CnstTyp == INT_VALUE || cnst->CnstTyp == FLOAT_VALUE || cnst->CnstTyp == BOOLEAN_VALUE)
	{

		rslt = bldBlnCnst(cnst->vl.intVl == 0);

	}
	else if (cnst->CnstTyp == STRING_VALUE)
	{
		//if (cnst->vl.str != NULL)
		if (cnst->vl.str->empty() == false)
		{
			rslt = bldBlnCnst(strcmp(cnst->vl.str->c_str(), "") == 0);
		}
		else
		{
			rslt = bldBlnCnst(0);
		}

	}
	else if (cnst->CnstTyp == ARRAY_VALUE)
	{
		if (cnst->vl.arr->elmtArr.size() == 0)
		{
			rslt = bldBlnCnst(1);
		}
		else
		{
			rslt = bldBlnCnst(0);
		}
	}

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;
}

struct CnstStrc* clcUnrExpBitNot(vector<EnvrStrc*>& envr, struct UnrExpStrc* exp)
{

	struct CnstStrc* rslt;

	struct CnstStrc* cnst;
	cnst = clcExp(envr, exp->exp);

	if (cnst->CnstTyp == INT_VALUE || cnst->CnstTyp == FLOAT_VALUE || cnst->CnstTyp == BOOLEAN_VALUE)
	{
		rslt = bldCnstCpy(cnst);
		rslt->vl.intVl = ~rslt->vl.intVl;
	}
	// else if (cnst->CnstTyp == STRING_VALUE)
	// {
	//     if (cnst->vl.str !=NULL)
	//     {
	//         rslt = bldBlnCnst(strcmp(cnst->vl.str,"")!=0);
	//     }
	//     else
	//     {
	//         rslt = bldBlnCnst(0);
	//     }

	// }
	// else if (cnst->CnstTyp == ARRAY_VALUE)
	// {
	//     if (cnst->vl.arr->elmtCnt > 0 )
	//     {
	//         rslt= bldBlnCnst(1);
	//     }
	//     else
	//     {
	//         rslt= bldBlnCnst(0);
	//     }
	// }

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;
}

struct CnstStrc* clcUnrExpSub(vector<EnvrStrc*>& envr, struct UnrExpStrc* exp)
{
	struct CnstStrc* cnst, * rslt;

	rslt = NULL;

	cnst = clcExp(envr, exp->exp);

	if (cnst->CnstTyp == INT_VALUE)
	{
		rslt = bldIntCnst(-cnst->vl.intVl);
	}
	else if (cnst->CnstTyp == FLOAT_VALUE)
	{
		rslt = bldFltCnst(-cnst->vl.flt);
	}
	else if (cnst->CnstTyp == BOOLEAN_VALUE)
	{
		rslt = bldBlnCnst(cnst->vl.bln);
	}

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;
}

struct CnstStrc* clcUnrExpAdd(vector<EnvrStrc*>& envr, struct UnrExpStrc* exp)
{
	struct CnstStrc* cnst, * rslt;

	rslt = NULL;

	cnst = clcExp(envr, exp->exp);

	rslt = bldCnstCpy(cnst);

	if (rslt == NULL)
	{
		throw new ExWrgOprndTyp;
	}

	return rslt;
}

struct CnstStrc* clcUnrExp(vector<EnvrStrc*>& envr, struct UnrExpStrc* exp)
{
	struct CnstStrc* rslt;

	switch (exp->oprTyp)
	{
	case PREFIX_INCREMENT:
	{
		rslt = clcUnrExpPfxInc(envr, exp);
		break;
	}
	case PREFIX_DECREMENT:
	{
		rslt = clcUnrExpPfxDec(envr, exp);
		break;
	}
	case SUFFIX_INCREMENT:
	{
		rslt = clcUnrExpSfxInc(envr, exp);
		break;
	}
	case SUFFIX_DECREMENT:
	{
		rslt = clcUnrExpSfxDec(envr, exp);
		break;
	}
	case NOT:
	{
		rslt = clcUnrExpNot(envr, exp);
		break;
	}
	case BIT_NOT:
	{
		rslt = clcUnrExpBitNot(envr, exp);
		break;
	}
	case SUB:
	{
		rslt = clcUnrExpSub(envr, exp);
		break;
	}
	case ADD:
	{
		rslt = clcUnrExpAdd(envr, exp);
		break;
	}


	}

	return rslt;
}

struct CnstStrc* clcFcnExp(vector<EnvrStrc*>& envr, struct FcnExpStrc* exp)
{
	struct CnstStrc* rslt = new CnstStrc;

	struct NtvFcnStrc* ntvFcn;

	ntvFcn = getNtvFcn(envr, exp);

	struct FcnStrc* fcn;

	fcn = getFcn(envr, exp);

	if (ntvFcn == nullptr && fcn == nullptr)
	{
		throw new ExFcnNotFnd;
	}
	else if (ntvFcn != nullptr)
	{
		//计算各个参数的值并赋值给传参数组

		int i;

		struct CnstStrc* arg;
		int argCnt = 0, argSz;

		//如果函数参数个数不正确
		if (exp->argLst->argArr.size() > ntvFcn->prmCnt)
		{
			throw new ExFcnTooMnyArg;
		}
		else if (exp->argLst->argArr.size() < ntvFcn->prmCnt)
		{
			throw new ExFcnTooFewArg;
		}

		//struct CnstStrc** argArr = (struct CnstStrc**)malloc(sizeof(struct CnstStrc*) * ntvFcn->prmCnt);
		vector<CnstStrc*> argArr;

		//printf("clc fcn prm cnt: %d\n", exp->argLst->argArr.size());

		for (i = 0; i < exp->argLst->argArr.size(); i++)
		{
			//printf("ntvFcn arg[%2d] typ: %d\n", i, exp->argLst->argArr.at(i)->typ);

			arg = clcExp(envr, exp->argLst->argArr[i]);

			//printf("aft clc ntvFcn arg[%2d] typ: %d\n", i, exp->argLst->argArr.at(i)->typ);

			argArr.push_back(arg);
		}

		rslt = ntvFcn->fcn(envr, ntvFcn->prmCnt, argArr);
	}
	else if (fcn != nullptr)
	{
		//在建立函数环境前，计算实参的各个值

		for (int i = 0; i < exp->argLst->argArr.size(); i++)
		{
			printf("bfr argArr[%d] typ: %d\n", i, exp->argLst->argArr[i]->typ);

			if (exp->argLst->argArr[i] != nullptr)
			{
				exp->argLst->argArr[i] = clcExp(envr, exp->argLst->argArr[i]);
			}

			printf("aft argArr[%d] typ: %d\n", i, exp->argLst->argArr[i]->typ);
		}

		//建立函数中的EnvrStrc

		struct EnvrStrc* envrFcn = new EnvrStrc(FUNCTION_ENVIRONMENT);

		envr.push_back(envrFcn);

		//计算各个参数的值并赋值给形参

		int i;

		struct CnstStrc* arg;
		int argCnt = 0, argSz;

		//此处暂时屏蔽
		//如果函数参数个数不正确
		//if (exp->argLst->argArr.size() > fcn->prmLst->prmArr.size())
		//{
		//	throw new ExFcnTooMnyArg;
		//}
		//else if (exp->argLst->argArr.size() < fcn->prmLst->prmArr.size())
		//{
		//	throw new ExFcnTooFewArg;
		//}

		struct VrbStrc* vrb;

		//函数参数赋值
		for (i = 0; i < exp->argLst->argArr.size(); i++)
		{
			//位置参数赋值
			if (exp->argLst->prmArr[i] == nullptr)
			{
				printf("bfr lctn prm asgn: typ: %d\n", exp->argLst->argArr[i]->typ);

				arg = clcExp(envr, exp->argLst->argArr[i]);

				printf("bfr lctn prm asgn: arg: cnstTyp: %d typ: %d\n",arg->CnstTyp, arg->typ);

				vrb = addVrb(envrFcn, fcn->prmLst->prmArr[i]);

				asgnVrb(vrb, arg);

				printf("aft lctn prm asgn: typ: %d\n", vrb->typ);
			}
			//关键字参数赋值
			else
			{
				arg = clcExp(envr, exp->argLst->argArr[i]);
				vrb = getEnvrVrb(envrFcn, exp->argLst->prmArr[i]);

				if (vrb == nullptr)
				{
					vrb = addVrb(envrFcn, exp->argLst->prmArr[i]);
				}

				asgnVrb(vrb, arg);
			}
		}

		for (i = 0; i < fcn->prmLst->prmArr.size(); i++)
		{
			//默认参数赋值
			vrb = getEnvrVrb(envrFcn, fcn->prmLst->prmArr[i]);

			if (vrb == nullptr && fcn->prmLst->expArr[i] != nullptr)
			{
				vrb = addVrb(envrFcn, fcn->prmLst->prmArr[i]);
				arg = clcExp(envr, fcn->prmLst->expArr[i]);

				asgnVrb(vrb, arg);
			}
		}

		struct StmtRsltStrc* stmtRslt;

		stmtRslt = exctStmt(envr, fcn->stmt);

		if (stmtRslt->typ == RtnEnm::Rtn && stmtRslt->rslt.rtnRslt->blnRslt == 1)
		{
			rslt = stmtRslt->rslt.rtnRslt->rslt;
		}

		envr.pop_back();
	}


	return rslt;

}

/// <summary>
/// 使用函数结构体以及函数表达式结构体计算函数表达式
/// </summary>
struct CnstStrc* clcFcnExp(vector<EnvrStrc*>& envr, struct FcnStrc* fcn, struct FcnExpStrc* exp)
{
	struct CnstStrc* rslt = new CnstStrc;

	if (fcn != nullptr)
	{
		//在建立函数环境前，计算实参的各个值

		for (int i = 0; i < exp->argLst->argArr.size(); i++)
		{
			if (exp->argLst->argArr[i] != nullptr)
			{
				exp->argLst->argArr[i] = clcExp(envr, exp->argLst->argArr[i]);
			}
		}

		//建立函数中的EnvrStrc

		struct EnvrStrc* envrFcn = new EnvrStrc(FUNCTION_ENVIRONMENT);

		envr.push_back(envrFcn);

		//计算各个参数的值并赋值给形参

		int i;

		struct CnstStrc* arg;
		int argCnt = 0, argSz;

		//此处暂时屏蔽
		//如果函数参数个数不正确
		//if (exp->argLst->argArr.size() > fcn->prmLst->prmArr.size())
		//{
		//	throw new ExFcnTooMnyArg;
		//}
		//else if (exp->argLst->argArr.size() < fcn->prmLst->prmArr.size())
		//{
		//	throw new ExFcnTooFewArg;
		//}

		struct VrbStrc* vrb;

		//函数参数赋值
		for (i = 0; i < exp->argLst->argArr.size(); i++)
		{
			//位置参数赋值
			if (exp->argLst->prmArr[i] == nullptr)
			{
				arg = clcExp(envr, exp->argLst->argArr[i]);

				vrb = addVrb(envrFcn, fcn->prmLst->prmArr[i]);

				asgnVrb(vrb, arg);
			}
			//关键字参数赋值
			else
			{
				arg = clcExp(envr, exp->argLst->argArr[i]);
				vrb = getEnvrVrb(envrFcn, exp->argLst->prmArr[i]);

				if (vrb == nullptr)
				{
					vrb = addVrb(envrFcn, exp->argLst->prmArr[i]);
				}

				asgnVrb(vrb, arg);
			}
		}

		for (i = 0; i < fcn->prmLst->prmArr.size(); i++)
		{
			//默认参数赋值
			vrb = getEnvrVrb(envrFcn, fcn->prmLst->prmArr[i]);

			if (vrb == nullptr && fcn->prmLst->expArr[i] != nullptr)
			{
				vrb = addVrb(envrFcn, fcn->prmLst->prmArr[i]);
				arg = clcExp(envr, fcn->prmLst->expArr[i]);

				asgnVrb(vrb, arg);
			}
		}

		struct StmtRsltStrc* stmtRslt;

		stmtRslt = exctStmt(envr, fcn->stmt);

		if (stmtRslt->typ == RtnEnm::Rtn && stmtRslt->rslt.rtnRslt->blnRslt == 1)
		{
			rslt = stmtRslt->rslt.rtnRslt->rslt;
		}

		envr.pop_back();
	}


	return rslt;

}






//struct CnstStrc* clcLclAsgnExp(vector<EnvrStrc*>& envr, struct LclAsgnExpStrc* exp)
//{
//	struct CnstStrc* rslt = NULL;
//	struct VrbStrc* vrb;
//
//	int i;
//
//	for (i = 0; i < exp->asgnLst->asgnArr.size(); i++)
//	{
//		struct VrbExpStrc* vrbExp;
//
//		vrbExp = exp->asgnLst->asgnArr[i]->exp.asgnExp->lvl->exp.lvlExp->vrb->exp.vrbExp;
//
//
//		if ((vrb = getEnvrVrb(fcnEnvr, vrbExp)) == NULL)
//		{
//			vrb = addVrb(fcnEnvr, vrbExp);
//		}
//
//		if (exp->asgnLst->asgnArr[i]->exp.asgnExp->exp->typ != NULL_EXPRESSION)
//		{
//			rslt = clcExp(envr, exp->asgnLst->asgnArr[i]->exp.asgnExp->exp);
//			asgnVrb(vrb, rslt);
//		}
//		else
//		{
//			asgnVrb(vrb, bldNllCnst());
//			rslt = bldNllCnst();
//
//		}
//	}
//
//
//	return rslt;
//}



struct CnstStrc* clcAsgnExp(vector<EnvrStrc*>& envr, struct AsgnExpStrc* exp)
{

	struct CnstStrc* rslt = new CnstStrc;

	rslt = clcExp(envr, exp->exp);

	struct LvlExpStrc* lvl;

	lvl = static_cast<LvlExpStrc*>(exp->lvl);

	struct VrbStrc* vrb;

	//vrb = getVrb(envr, static_cast<VrbExpStrc*> (lvl->vrb));
	vrb = getVrb(envr, lvl);

	//printf("clc obj vrb: %s\n", rslt->vl.obj->vrb.back()->nm->c_str());

	if (lvl->hasAcsLst == 0)
	{
		asgnVrb(vrb, rslt);
		//printf("vrb asgn: typ: %d\n", vrb->typ);
		//printf("vrb asgn: ctn vrb: %s\n", vrb->vl.obj->vrb.back()->nm->c_str());
	}
	//定位到数组元素的情况
	else
	{

		int pstn;

		struct CnstStrc* arrTmp;

		arrTmp = bldCnstFrmVrb(vrb);

		int lyr;

		lyr = lvl->acs->acsLst.size();

		int i;

		for (i = 0; i < lyr; i++)
		{
			if (arrTmp->CnstTyp != ARRAY_VALUE)
			{
				throw new ExNotAvlbArr;
			}

			pstn = clcExp(envr, lvl->acs->acsLst[i]->pstn)->vl.intVl;

			if (pstn >= arrTmp->vl.arr->elmtArr.size())
			{
				throw new ExIdxOutArrRng;
			}

			if (i < lyr - 1)
			{
				arrTmp = arrTmp->vl.arr->elmtArr[pstn];
			}

		}

		if (pstn >= arrTmp->vl.arr->elmtArr.size())
		{
			throw new ExIdxOutArrRng;
		}

		arrTmp->vl.arr->elmtArr[pstn] = rslt;
	}


	return rslt;
}

struct CnstStrc* clcArrExp(vector<EnvrStrc*>& envr, struct ArrExpStrc* exp)
{
	struct CnstStrc* rslt = new CnstStrc;

	rslt->CnstTyp = ARRAY_VALUE;

	int elmtCnt;

	rslt->vl.arr = new ArrStrc;

	int i;

	elmtCnt = exp->elmtLst->elmtArr.size();

	printf("arr: %d:", elmtCnt);

	for (i = 0; i < elmtCnt; i++)
	{
		//rslt->vl.arr->elmtArr[i] = clcExp(envr, exp->elmtLst->elmtArr[i]);
		rslt->vl.arr->elmtArr.push_back(clcExp(envr, exp->elmtLst->elmtArr[i]));

		//printf("%d, ", rslt->vl.arr->elmtArr.back()->vl.intVl);
	}


	return rslt;
}

struct CnstStrc* clcNewArrExp(vector<EnvrStrc*>& envr, struct NewArrExpStrc* exp)
{
	struct CnstStrc* rslt = new CnstStrc;

	rslt->CnstTyp = ARRAY_VALUE;

	//rslt->vl.arr = (struct ArrStrc*)malloc(sizeof(struct ArrStrc*));
	rslt->vl.arr = new ArrStrc;

	int elmtCnt;

	elmtCnt = clcExp(envr, exp->cnt)->vl.intVl;

	//rslt->vl.arr->elmtSz = elmtCnt + 0x10;
	//rslt->vl.arr->elmtCnt = elmtCnt;

	//rslt->vl.arr->elmtArr = (struct CnstStrc**)malloc(sizeof(struct CnstStrc*) * rslt->vl.arr->elmtSz);

	int i;

	for (i = 0; i < elmtCnt; i++)
	{
		//rslt->vl.arr->elmtArr[i] = bldNllCnst();
		rslt->vl.arr->elmtArr.push_back(bldNllCnst());
	}

	return rslt;
}

//struct CnstStrc* clcArrEvlExp(vector<EnvrStrc*>& envr, struct ArrEvlExpStrc* exp)
//{
//	struct CnstStrc* rslt = new CnstStrc;
//
//	int pstn;
//
//	struct VrbStrc* arr;
//	struct CnstStrc* arrTmp, * arrTmp2;
//
//	struct ArrStrc* arrNew;
//
//
//	arr = getVrb(envr, exp->arr->exp.vrbExp);
//
//	int i;
//	int j;
//
//	int strt, end, stp;
//
//	//arrTmp用于迭代取数组的值
//	arrTmp = bldCnstFrmVrb(arr);
//
//	for (i = 0; i < exp->evlLst->evlCnt; i++)
//	{
//		if (exp->evlLst->blnSlc[i] == 0)
//		{
//			pstn = clcExp(envr, exp->evlLst->pstnArr[i])->vl.intVl;
//
//			//如果数组索引为负数，实际的数组索引为数组索引值（负数）加数组长度
//			if (pstn < 0)
//			{
//				pstn = arrTmp->vl.arr->elmtArr.size() + pstn;
//			}
//
//			arrTmp = arrTmp->vl.arr->elmtArr[pstn];
//		}
//
//		if (exp->evlLst->blnSlc[i] != 0)
//		{
//			intlArr(&arrNew);
//
//			strt = clcExp(envr, exp->evlLst->strtArr[i])->vl.intVl;
//			end = clcExp(envr, exp->evlLst->endArr[i])->vl.intVl;
//			stp = clcExp(envr, exp->evlLst->stpArr[i])->vl.intVl;
//
//			if (strt < 0)
//			{
//				strt = arrTmp->vl.arr->elmtArr.size() + strt;
//			}
//
//			if (end < 0)
//			{
//				end = arrTmp->vl.arr->elmtArr.size() + end;
//			}
//
//			if (strt <= end && stp > 0)
//			{
//				for (j = strt; j <= end; j += stp)
//				{
//					addElmt(arrNew, arrTmp->vl.arr->elmtArr[j]);
//				}
//			}
//
//			if (strt > end && stp < 0)
//			{
//				for (j = strt; j >= end; j += stp)
//				{
//					addElmt(arrNew, arrTmp->vl.arr->elmtArr[j]);
//				}
//			}
//
//
//			arrTmp = bldArrCnst(arrNew);
//		}
//
//	}
//
//	//获得得取值结果应该是值，不是引用
//	rslt = bldCnstCpy(arrTmp);
//
//	return rslt;
//
//}

struct CnstStrc* clcElmtAsgnExp(vector<EnvrStrc*>& envr, struct ElmtAsgnExpStrc* exp)
{
	struct CnstStrc* rslt = new CnstStrc;

	int pstn;

	struct VrbStrc* arr;

	arr = getVrb(envr, static_cast<VrbExpStrc*>(exp->arr));

	struct ArrStrc* arrPrnt;

	arrPrnt = arr->vl.arr;

	int lyr;

	lyr = exp->pstnLst->pstnArr.size();

	int i;

	for (i = 0; i < lyr - 1; i++)
	{
		pstn = clcExp(envr, exp->pstnLst->pstnArr[i])->vl.intVl;
		arrPrnt = arrPrnt->elmtArr[pstn]->vl.arr;
	}

	rslt = clcExp(envr, exp->vl);

	pstn = clcExp(envr, exp->pstnLst->pstnArr[lyr - 1])->vl.intVl;

	arrPrnt->elmtArr[pstn] = rslt;

	return rslt;


}


struct CnstStrc* clcLvlExp(vector<EnvrStrc*>& envr, struct LvlExpStrc* exp)
{
	struct CnstStrc* rslt = new CnstStrc;

	struct VrbStrc* vrb;

	vrb = getVrb(envr, exp->vrb);

	//printf("vrb == nullptr: %d typ: %d\n", vrb == nullptr, vrb->typ);

	if (vrb == nullptr)
	{
		throw new ExVrbNotFnd();
		return nullptr;
	}

	FcnExpStrc* fcnExp = nullptr;
	FcnStrc* fcn = nullptr;

	//如果是调用对象的函数
	if (exp->blnIvk)
	{
		printf("clc lvl exp obj fcn\n");

		fcn = getObjFcn(vrb, exp);

		while (exp->hasAtb == 1)
		{
			exp = exp->atb;
		}

		rslt = clcFcnExp(envr, fcn, exp->fcn);

		return rslt;
	}

	//如果左值表达式中有属性
	if (exp->hasAtb == 1)
	{
		printf("hasAtb typ: %d tgt typ: %d\n", vrb->typ, OBJECT_VALUE);

		vrb = getObjVrb(vrb, exp);

		while (exp->hasAtb == 1)
		{
			exp = exp->atb;
		}
	}

	//如果是变量名的情况
	if (exp->hasAcsLst == 0)
	{
		//printf("hasAcsLst == 0 vrb typ: %d\n", vrb->typ);

		rslt = bldCnstFrmVrb(vrb);

		//printf("hasAcsLst == 0 rslt typ: %d\n", rslt->typ);

		if (rslt->typ == -842150451)
		{
			throw 123;
		}
	}
	//如果是数组评估表达式的情况
	else
	{
		int pstn;

		struct CnstStrc* arrTmp, * arrTmp2;

		struct ArrStrc* arrNew;


		int i;
		int j;

		int strt, end, stp;

		printf("vrb typ: %d\n", vrb->typ);
		//arrTmp用于迭代取数组的值
		arrTmp = bldCnstFrmVrb(vrb);

		printf("arrTmp typ: %d\n", arrTmp->CnstTyp);

		int lyr = exp->acs->acsLst.size();

		for (i = 0; i < lyr; i++)
		{
			printf("clcLvlExp cnst typ: %d\n", arrTmp->CnstTyp);
			//检查是否是有效的数组
			//if (arrTmp->CnstTyp != LVALUE_EXPRESSION)
			//{
			//	throw new ExNotAvlbArr;
			//}

			//该层为数组索引的情况
			if (exp->acs->acsLst[i]->blnSlc == 0)
			{
				pstn = clcExp(envr, exp->acs->acsLst[i]->pstn)->vl.intVl;

				//如果数组索引为负数，实际的数组索引为数组索引值（负数）加数组长度
				if (pstn < 0)
				{
					pstn = arrTmp->vl.arr->elmtArr.size() + pstn;
				}

				if (pstn >= arrTmp->vl.arr->elmtArr.size())
				{
					throw new ExIdxOutArrRng;
				}

				arrTmp = arrTmp->vl.arr->elmtArr[pstn];
			}

			if (exp->acs->acsLst[i]->blnSlc != 0)
			{
				intlArr(&arrNew);

				strt = clcExp(envr, exp->acs->acsLst[i]->strt)->vl.intVl;
				end = clcExp(envr, exp->acs->acsLst[i]->end)->vl.intVl;
				stp = clcExp(envr, exp->acs->acsLst[i]->stp)->vl.intVl;

				if (strt < 0)
				{
					strt = arrTmp->vl.arr->elmtArr.size() + strt;
				}

				if (end < 0)
				{
					end = arrTmp->vl.arr->elmtArr.size() + end;
				}

				if (strt >= arrTmp->vl.arr->elmtArr.size())
				{
					throw new ExIdxOutArrRng;
				}

				if (end >= arrTmp->vl.arr->elmtArr.size())
				{
					throw new ExIdxOutArrRng;
				}

				if (strt <= end && stp > 0)
				{
					for (j = strt; j <= end; j += stp)
					{
						addElmt(arrNew, arrTmp->vl.arr->elmtArr[j]);
					}
				}

				if (strt > end && stp < 0)
				{
					for (j = strt; j >= end; j += stp)
					{
						addElmt(arrNew, arrTmp->vl.arr->elmtArr[j]);
					}
				}

				arrTmp = bldArrCnst(arrNew);
			}

		}

		//获得得取值结果应该是值，不是引用
		rslt = bldCnstCpy(arrTmp);
	}

	return rslt;

}

struct CnstStrc* clcNewExp(vector<EnvrStrc*>& envr, struct NewExpStrc* exp)
{
	ClsStrc* cls = nullptr;

	printf("new exp: %s\n", exp->nm->c_str());

	cls = getGlbCls(envr, *(exp->nm));

	if (cls != nullptr)
	{
		printf("get cls\n");
		auto obj = istObj(cls);

		return obj;
	}
	else
	{
		throw ExClsNotDfn();
	}
}

struct CnstStrc* clcExp(vector<EnvrStrc*>& envr, struct ExpStrc* exp)
{
	struct CnstStrc* rslt = new CnstStrc;

	if (exp->typ == CONST_EXPRESSION)
	{
		rslt = static_cast<CnstStrc*>(exp);
	}

	if (exp->typ == VARIABLE_EXPRESSION)
	{
		struct VrbStrc* vrb = getVrb(envr, static_cast<VrbExpStrc*>(exp));

		//如果变量没有注册过，则注册变量并赋值为null
		if (vrb == NULL)
		{
			vrb = addVrb(envr[envr.size() - 1], static_cast<VrbExpStrc*>(exp));
			asgnVrb(vrb, bldNllCnst());
		}

		rslt = bldCnstFrmVrb(vrb);

	}

	if (exp->typ == BINARY_EXPRESSION)
	{
		rslt = clcBnrExp(envr, static_cast<BnrExpStrc*>(exp));
	}

	if (exp->typ == TERNARY_EXPRESSION)
	{
		rslt = clcTnrExp(envr, static_cast<TnrExpStrc*>(exp));
	}

	if (exp->typ == ASSIGN_EXPRESSION)
	{
		AsgnExpStrc* asgnExp = static_cast<AsgnExpStrc*>(exp);

		//如果已经注册为函数名则抛出异常
		if (getFcn(envr, static_cast<FcnExpStrc*>(bldFcnExp((char*)(asgnExp->lvl->vrb->nm.c_str()), NULL))) != NULL)
		{
			throw new ExAlrdDfnAsFctn;
		}

		if (getVrb(envr, asgnExp->lvl->vrb) == NULL)
		{
			addVrb(envr[envr.size() - 1], asgnExp->lvl->vrb);

			//printf("add vrb %s\n", asgnExp->lvl->vrb->nm.c_str());
		}

		rslt = clcAsgnExp(envr, asgnExp);

		//printf("aft asgn: rslt typ: %d cnst typ: %d\n", rslt->typ, rslt->CnstTyp);
		//printf("aft asgn: rslt vrb: %s typ: %d\n", rslt->vl.obj->vrb.back()->nm->c_str(), rslt->vl.obj->vrb.back()->typ);
	}

	if (exp->typ == UNARY_EXPRESSION)
	{
		rslt = clcUnrExp(envr, static_cast<UnrExpStrc*>(exp));
	}

	if (exp->typ == FUNCTION_EXPRESSION)
	{
		rslt = clcFcnExp(envr, static_cast<FcnExpStrc*>(exp));
	}

	if (exp->typ == ARRAY_EXPRESSION)
	{
		rslt = clcArrExp(envr, static_cast<ArrExpStrc*> (exp));
	}

	if (exp->typ == ELEMENT_ASSIGN_EXPRESSION)
	{
		rslt = clcElmtAsgnExp(envr, static_cast<ElmtAsgnExpStrc*>(exp));
	}

	if (exp->typ == NEW_ARRAY_EXPRESSION)
	{
		rslt = clcNewArrExp(envr, static_cast<NewArrExpStrc*>(exp));
	}

	if (exp->typ == LVALUE_EXPRESSION)
	{
		rslt = clcLvlExp(envr, static_cast<LvlExpStrc*>(exp));
	}

	if (exp->typ == NULL_EXPRESSION)
	{
		rslt = bldNllCnst();
	}

	if (exp->typ == NEW_EXPRESSION)
	{
		rslt = clcNewExp(envr, static_cast<NewExpStrc*>(exp));
	}

	if (exp->typ == INT_VALUE || exp->typ == FLOAT_VALUE || exp->typ == BOOLEAN_VALUE || exp->typ == STRING_VALUE || exp->typ == OBJECT_VALUE || exp->typ == ARRAY_VALUE || exp->typ == NULL_VALUE)
	{
		rslt = static_cast<CnstStrc*>(exp);
	}

	return rslt;
}


#endif